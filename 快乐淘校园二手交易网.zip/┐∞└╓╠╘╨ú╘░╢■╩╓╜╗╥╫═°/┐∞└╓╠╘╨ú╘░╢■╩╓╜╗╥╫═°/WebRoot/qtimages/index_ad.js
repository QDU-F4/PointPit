document.writeln("<script type=\'text\/javascript\'> ");
document.writeln("cpro_client=\'jiao15_cpr\';");
document.writeln("cpro_at=\'image\'; ");
document.writeln("cpro_161=3; ");
document.writeln("cpro_flush=4; ");
document.writeln("cpro_w=640; ");
document.writeln("cpro_h=60; ");
document.writeln("cpro_template=\'text_default_640_60\'; ");
document.writeln("cpro_cbd=\'#FFFFFF\'; ");
document.writeln("cpro_cbg=\'#FFFFFF\'; ");
document.writeln("cpro_ctitle=\'#0000ff\'; ");
document.writeln("cpro_cdesc=\'#444444\'; ");
document.writeln("cpro_curl=\'#008000\'; ");
document.writeln("cpro_cflush=\'#e10900\'; ");
document.writeln("cpro_uap=1;");
document.writeln("cpro_cad=1;");
document.writeln("<\/script>");
document.writeln("<script language=\'JavaScript\' type=\'text\/javascript\' src=\'http:\/\/cpro.baidu.com\/cpro\/ui\/cp.js\'><\/script>")